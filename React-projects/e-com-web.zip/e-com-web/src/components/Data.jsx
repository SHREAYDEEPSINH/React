export let InkWorkData = [
    {
        "id": 1,
        "title": "Street hen cock (30X21)",
        "price": "1800",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-01.jpg?v=1712914502&width=533"
    },
    {
        "id": 2,
        "title": "Fern Ink Blue Leaves",
        "price": "2600",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-02.jpg?v=1712914536&width=533"
    },
    {
        "id": 3,
        "title": "Set of 2 lotus flower",
        "price": "2900",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-03.jpg?v=1712914541&width=533"
    },
    {
        "id": 4,
        "title": "Abstract botanical",
        "price": "2900",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-04.jpg?v=1712914547&width=533"
    },
    {
        "id": 5,
        "title": "Purple French Rose",
        "price": "4000",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-05.jpg?v=1712914894&width=533"
    },
    {
        "id": 6,
        "title": "Indigo white leaf petals",
        "price": "3800",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-06.jpg?v=1712914928&width=533"
    },
    {
        "id": 7,
        "title": "Botanical Leaves Framed",
        "price": "1800",
        "img": "https://mb-demo1.myshopify.com/cdn/shop/files/ubone-arts-store-product-07-d.jpg?v=1712914945&width=533"
    },
    {
        "id": 8,
        "title": "Abstract Sky",
        "price": 500,
        "img": "https://i.pinimg.com/236x/b8/d3/73/b8d373a5fd7e570f5731288e196f68dd.jpg"
    },
    {
        "id": 9,
        "title": "Ocean Breeze",
        "price": 800,
        "img": "https://i.pinimg.com/236x/96/a5/0a/96a50a09fd9eee80b9d5ed55917c6295.jpg"
    },
    {
        "id": 10,
        "title": "Golden Hour",
        "price": 1200,
        "img": "https://i.pinimg.com/564x/0f/90/19/0f901973c3300154272634c2cf2c4479.jpg"
    },
    {
        "id": 11,
        "title": "Mountain Sunrise",
        "price": 1500,
        "img": "https://img.artpal.com/599592/8-23-10-27-5-25-21m.jpg"
    }
] 




export let AbstractArtData = [
    {
        "id": 12,
        "title": "Street hen cock (30X21)",
        "price": "1800",
        "img": "https://img.freepik.com/premium-photo/abstract-art-painting-closeup-acrylic-painting-canvas-modern-art-rich-texture-modern-art_946818-2068.jpg"
    },
    {
        "id": 13,
        "title": "Fern Ink Blue Leaves",
        "price": "2600",
        "img": "https://obsessedwithart.com/wp-content/uploads/2021/08/roads.not_.taken_.1500px.78x78in.2018-1002x1024.jpg"
    },
    {
        "id": 14,
        "title": "Set of 2 lotus flower",
        "price": "2900",
        "img": "https://i.pinimg.com/736x/f8/eb/e3/f8ebe3f8b3850cad827acea014209cb6.jpg"
    },
    {
        "id": 15,
        "title": "Abstract botanical",
        "price": "2900",
        "img": "https://d28jbe41jq1wak.cloudfront.net/BlogsImages/abstract_art_ThumbNail_638250928938646300.webp"
    },
    {
        "id": 16,
        "title": "Purple French Rose",
        "price": "4000",
        "img": "https://images.pexels.com/photos/1183992/pexels-photo-1183992.jpeg?cs=srgb&dl=pexels-steve-1183992.jpg&fm=jpg"
    },
    {
        "id": 17,
        "title": "Indigo white leaf petals",
        "price": "3800",
        "img": "https://apkainterior.gumlet.io/39364/621a10493b774_acrylic-abstract.jpg?w=360&dpr=2.6"
    },
    {
        "id": 18,
        "title": "Botanical Leaves Framed",
        "price": "1800",
        "img": "https://www.mediastorehouse.co.uk/p/708/navy-marble-32949204.jpg.webp"
    },
    {
        "id": 19,
        "title": "Abstract Sky",
        "price": 500,
        "img": "https://img.freepik.com/premium-photo/abstract-art-poster-blue-gold-abstract-expressionism-painting_561855-109852.jpg"
    }
] 



